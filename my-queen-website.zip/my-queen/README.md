# For My Queen 💜

A static, mobile-friendly romantic story website made with HTML, CSS and vanilla JavaScript.

## Project files

```text
my-queen/
├── index.html
├── style.css
├── script.js
└── assets/
    ├── photo1.jpg ... photo8.jpg
    └── watangoja.mp3
```

All eight supplied photos are included in the gallery. The supplied audio upload was converted to MP3 and included as `assets/watangoja.mp3` (about 3:13). Music begins after the first welcome-button tap because mobile browsers require a user gesture.

## Preview locally

Open `index.html` in a browser. For a more reliable local preview, run a static server from this folder:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages

1. Sign in to GitHub and create a new **public** repository, for example `my-queen`.
2. Open the repository and choose **Add file → Upload files**.
3. Upload the contents of this `my-queen` folder (the `index.html`, `style.css`, `script.js`, and `assets` folder). Do not upload only the ZIP file.
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch **main** and folder **/(root)**, then click **Save**.
8. Wait for GitHub Pages to publish. Your site address will appear in the Pages section, usually `https://YOUR-USERNAME.github.io/my-queen/`.

## Notes

- Keep the `assets` folder beside `index.html`; do not rename the photo or audio files unless you also update their references.
- The site uses no backend, database, paid hosting, or JavaScript libraries.
- Google Fonts are loaded online; if the phone is offline, the page falls back to system fonts.
- The song file is included in this private project archive. Only publish/share audio if you have permission to use it; a GitHub repository set to public makes the audio file publicly accessible.
- The photos are included exactly as supplied, without AI replacement or facial edits.
